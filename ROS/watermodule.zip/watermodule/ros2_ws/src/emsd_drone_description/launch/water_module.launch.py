"""Spawn the fixed water module assembly in a standalone Gazebo Fortress world."""
import os
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    share = Path(get_package_share_directory('emsd_drone_description'))
    urdf_path = share / 'urdf/water_module.urdf'
    resources = str(share.parent)
    existing = os.environ.get('IGN_GAZEBO_RESOURCE_PATH', '')
    if existing:
        resources += os.pathsep + existing
    return LaunchDescription([
        DeclareLaunchArgument('z', default_value='0.2', description='Spawn height in metres'),
        SetEnvironmentVariable('IGN_GAZEBO_RESOURCE_PATH', resources),
        ExecuteProcess(cmd=['ign', 'gazebo', '-r', str(share / 'worlds/water_module.sdf')],
                       output='screen'),
        Node(package='robot_state_publisher', executable='robot_state_publisher',
             parameters=[{'robot_description': urdf_path.read_text(), 'use_sim_time': True}],
             output='screen'),
        Node(package='ros_gz_sim', executable='create',
             arguments=['-world', 'water_module_test', '-name', 'water_module',
                        '-file', str(urdf_path), '-z', LaunchConfiguration('z')],
             output='screen'),
    ])
