# Water module only

Matching environment: Ubuntu 22.04, ROS 2 Humble, Gazebo Fortress, and a graphical desktop with working graphics drivers.
Install ROS 2 Humble using its official instructions:
https://docs.ros.org/en/humble/Installation/Ubuntu-Install-Debs.html
With the ROS apt repository configured, install dependencies:

    sudo apt update
    sudo apt install ros-humble-ros-gz ros-humble-robot-state-publisher ros-humble-ament-cmake ros-humble-launch-ros ros-humble-ament-index-python python3-colcon-common-extensions

Gazebo Fortress must provide the ign gazebo command. Installation instructions:
https://gazebosim.org/docs/fortress/install_ubuntu/

Extract the ZIP and open a terminal in the extracted watermodule directory:

    source /opt/ros/humble/setup.bash
    cd ros2_ws
    colcon build --symlink-install --packages-select emsd_drone_description
    source install/setup.bash
    ros2 launch emsd_drone_description water_module.launch.py

For subsequent launches, source both setup files; rebuilding is unnecessary.
This opens only the water module and ground plane. Spawn height is 0.2 m;
append z:=0.5 to change it. Stop with Ctrl+C.

The package name is retained for mesh URI compatibility. Use this standalone
workspace separately from a workspace already containing emsd_drone_description.
Other ROS/Gazebo versions may need launch-file adaptations. Windows/macOS need
an Ubuntu environment with working GUI and graphics support.

Included: URDF, 20 STL meshes, Gazebo world, launch file, mass-property report,
minimal ROS package/build files, original STEP. No drone, ArduPilot, or CAD
software is required to run it. System dependencies are installed separately.

All joints are fixed. Assumed total mass: 0.482 kg with uniform effective density.
No servo movement, buoyancy, or water flow. Collision cavities may be convexified.
URDF parsing and SDF conversion passed on the source PC; the archive has not
been tested on a second PC.
