# Start SITL, plot the response, and tune the drone

This setup connects **ArduCopter SITL + Gazebo Fortress + MAVROS**. Gazebo
simulates the EMSD vehicle and measured motor curves; ArduPilot runs the estimator,
position, attitude, rate control, and motor mixer. ROS 2 sends flight commands
through MAVROS. The Python PID gains in `control/config/drone.json` do not tune
this ArduPilot flight path.

## Build and launch

For dependencies and first-time installation, see
[ArduPilot integration](simulation/ARDUPILOT.md).

After changing package files, build from the project root:

```bash
cd ~/Desktop/EMSD
source /opt/ros/humble/setup.bash
cd ros2_ws
colcon build --symlink-install --packages-select emsd_drone_description
source install/setup.bash
cd ..

PYTHONNOUSERSITE=1 ros2 launch emsd_drone_description ardupilot_gazebo.launch.py
```

Leave that terminal running. Open **QGroundControl** and connect over **UDP port
14550** to inspect vehicle messages, save parameter backups, and edit gains.
Wait for estimator readiness before arming.

## Fix the gyro-rate pre-arm check

If arming prints:

```text
Arm: Gyro 0 rate 400Hz < loop rate*1.8 720Hz
```

The 400 Hz gyro stream is too slow for the active 400 Hz control loop. The
simulation defaults in `ros2_ws/src/emsd_drone_description/config/ardupilot/emsd.parm`
now specify `SCHED_LOOP_RATE 200`, whose minimum gyro requirement is 360 Hz.
This keeps the 400 Hz Gazebo/JSON simulation step unchanged.

Existing saved SITL parameters override defaults. With the simulation running,
open another terminal and set the saved value:

```bash
source /opt/ros/humble/setup.bash
source ~/Desktop/EMSD/ros2_ws/install/setup.bash

ros2 service call /mavros/param/set mavros_msgs/srv/ParamSetV2 \
  "{param_id: 'SCHED_LOOP_RATE', value: {type: 2, integer_value: 200}}"
```

Require `success: true`. **Stop the complete simulation launch with Ctrl+C and
relaunch it using the launch command above.** This parameter only takes effect
after restart. Confirm the saved value in QGroundControl. If the same 720 Hz
message returns, the running loop is still 400 Hz; check the parameter value and
that the correct SITL instance was restarted. Keep the pre-arm checks enabled.

## Take off and land

In a second terminal:

```bash
source /opt/ros/humble/setup.bash
source ~/Desktop/EMSD/ros2_ws/install/setup.bash

ros2 run emsd_drone_description ardupilot_command.py status
ros2 run emsd_drone_description ardupilot_command.py mode GUIDED &&
ros2 run emsd_drone_description ardupilot_command.py arm &&
ros2 run emsd_drone_description ardupilot_command.py takeoff 2
```

The `&&` sequence stops if a command fails and sends takeoff promptly after
arming. Successful arming followed by disarming about ten seconds later without
takeoff is consistent with the automatic disarm timeout.

The helper confirms mode and arming changes from vehicle heartbeats. A
`mode_sent=True` service response alone does not establish the active mode.
Takeoff service acceptance also does not establish that the target altitude has
been reached; inspect telemetry.

To land:

```bash
ros2 run emsd_drone_description ardupilot_command.py land
```

Wait for touchdown and automatic disarming before stopping the simulation.

## Diagnose rejected commands

`result=4` is a generic command execution failure; the accompanying ArduPilot
message supplies the reason. The helper prints `ArduPilot:` messages. To monitor
them continuously, open another sourced terminal:

```bash
ros2 topic echo /mavros/statustext/recv --qos-reliability best_effort
```

Leave it running while retrying the failed command. MAVROS publishes this topic
with best-effort reliability; a reliable subscription causes an incompatible-QoS
warning and receives no messages. The helper now uses compatible QoS.

Correct the reported `Arm:` or `PreArm:` issue before retrying takeoff. An
`Arming motors` message means that attempt succeeded; `Disarming motors` later
is a separate event.

## Plot the flight response

Gazebo writes ground-truth telemetry to `simulation/runs/<run>/telemetry.csv`.
Plot a snapshot of the latest ArduPilot run:

```bash
cd ~/Desktop/EMSD
python3 tools/plot_ardupilot_response.py
```

Or select a specific run and requested height:

```bash
python3 tools/plot_ardupilot_response.py \
  simulation/runs/20261108_180605_6460/telemetry.csv --target 2
```

This produces `response.png`, `response.pdf`, and `response.json` alongside the
CSV. Panels show height above the resting position, horizontal displacement,
roll/pitch/yaw, and four motor PWM outputs. Matplotlib and NumPy are required.

The dashed reference is the user-supplied requested height, **not a recorded
controller target**. Time zero is detected liftoff rather than the takeoff
command timestamp. Resting height is estimated from simulation seconds 1–5.
The final five-second statistics may include landing and are not automatically
hover statistics. Ground truth and ArduPilot's home/estimated altitude can have
different offsets.

The inspected `20261108_180605_6460` snapshot shows takeoff, hover, and landing.
Peak height above rest was approximately **2.344 m**, or **17% above the requested
2 m reference**. Hover showed persistent roll oscillation around ±2° and large
motor-output swings. This demonstrates flight in that run, but does not establish
a finished tune or identify a unique gain adjustment. Investigate roll-rate
tracking before increasing outer-loop altitude gains.

## Tune in stages

Save a parameter backup first. Change one parameter at a time, use small trial
changes, and repeat the same takeoff/hover/landing sequence. Compare separate
flight phases rather than averaging landing into hover performance.

| Order | Tune or validate | Evidence to inspect |
| --- | --- | --- |
| 1 | Mass, inertia, centre of mass, motor positions, thrust mapping, motor lag | Physical measurements and plausible motor thrust |
| 2 | `MOT_PWM_*`, `MOT_SPIN_*`, `MOT_THST_EXPO`, hover thrust | Stable hover with motor headroom |
| 3 | `ATC_RAT_RLL_*`, then pitch and yaw rate gains | Demanded versus actual rates, oscillation, motor activity |
| 4 | `ATC_ANG_*`, input shaping and angular acceleration limits | Smooth attitude tracking |
| 5 | Vertical acceleration, velocity, then position loops | Overshoot, settling, estimator versus ground-truth height |
| 6 | Horizontal velocity/position and navigation limits | Small position-step tracking |

P strengthens correction of current error. I removes persistent error. D adds
damping but increases sensitivity to noise. Persistent oscillation can also come
from actuator lag, filtering, or model errors; the altitude curve alone cannot
determine which gain to change. Inspect noise before tuning filters, and obtain
a basically flyable vehicle before attempting AutoTune.

The local ArduPilot source uses **`PSC_D_ACC_*`, `PSC_D_VEL_*`, and
`PSC_D_POS_P`** for vertical control and `PSC_NE_*` for horizontal control.
Older versions use `PSC_ACCZ_*`, `PSC_VELZ_*`, `PSC_POSZ_P`, and XY names.
Some numerical scales changed too: local acceleration P/I/D use 0.1 times the
older values. Check the actual firmware metadata before applying an example.

Use QGroundControl to edit and read back parameters, or set an existing
floating-point parameter through MAVROS (replace `NAME` and `VALUE`):

```bash
ros2 service call /mavros/param/set mavros_msgs/srv/ParamSetV2 \
  "{param_id: 'NAME', value: {type: 3, double_value: VALUE}}"
```

Require `success: true`, read back the value, and restart when parameter metadata
requires it. Parameter changes persist between runs. Avoid `wipe:=true` unless
you intend to reset saved settings.

For desired/actual rates, PID terms, estimator altitude, and controller targets,
inspect available DataFlash messages in
`simulation/runs/ardupilot_state/logs/*.BIN`. Relevant message families include
RATE, ATT, CTUN, RCOU, and PID messages where enabled. The CSV alone cannot show
command delay or rate tracking error because it lacks those demands and timestamps.

See the [detailed EMSD tuning guide](control/ARDUPILOT_TUNING.md) and the
[official ArduPilot tuning process](https://ardupilot.org/copter/docs/tuning-process-instructions.html).
The current plant has provisional motor mapping and assumed lag/drag; simulation
gains require separate validation for hardware.

## Combined ROS source archive

`exports/EMSD_ROS_complete.zip` contains the ROS package sources and required
simulation/control files, with generated build outputs and saved SITL state
excluded. Extract its `EMSD_ROS` folder into your Git repository and preserve the
relative layout. After changing source or documentation, regenerate the ZIP to
include those updates.
