#!/usr/bin/env python3
"""Editable ROS outer position controller; ArduPilot retains attitude/rate control."""
import argparse
import math

import rclpy
from geometry_msgs.msg import PoseStamped, TwistStamped
from rclpy.qos import qos_profile_sensor_data


def velocity_controller(position, target, kp, limit):
    """Replace this function with your controller. Inputs/outputs are world ENU."""
    error = [goal-actual for actual, goal in zip(position, target)]
    speed = math.sqrt(sum((kp*e)**2 for e in error))
    scale = min(1., limit / max(speed, 1e-9))
    return [scale*kp*e for e in error]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', nargs=3, type=float, default=[0., 0., 2.])
    parser.add_argument('--kp', type=float, default=.5)
    parser.add_argument('--max-speed', type=float, default=.5)
    args = parser.parse_args()
    if not all(math.isfinite(v) for v in [*args.target, args.kp, args.max_speed]) or args.kp <= 0 or args.max_speed <= 0:
        parser.error('Use finite targets and positive kp/max-speed')
    rclpy.init()
    node = rclpy.create_node('emsd_external_controller')
    position = None
    last_feedback = None

    def feedback(msg):
        nonlocal position, last_feedback
        position = [msg.pose.position.x, msg.pose.position.y, msg.pose.position.z]
        last_feedback = node.get_clock().now()

    publisher = node.create_publisher(TwistStamped, '/mavros/setpoint_velocity/cmd_vel', 10)
    node.create_subscription(PoseStamped, '/mavros/local_position/pose', feedback, qos_profile_sensor_data)

    def update():
        now = node.get_clock().now()
        message = TwistStamped()
        message.header.stamp = now.to_msg()
        message.header.frame_id = 'map'
        velocity = [0., 0., 0.]
        if position is not None and (now-last_feedback).nanoseconds < 500_000_000:
            velocity = velocity_controller(position, args.target, args.kp, args.max_speed)
        message.twist.linear.x, message.twist.linear.y, message.twist.linear.z = velocity
        publisher.publish(message)

    node.create_timer(.05, update)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        publisher.publish(TwistStamped())
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
