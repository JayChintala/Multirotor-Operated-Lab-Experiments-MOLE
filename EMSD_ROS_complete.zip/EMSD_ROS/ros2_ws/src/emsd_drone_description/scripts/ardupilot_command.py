#!/usr/bin/env python3
"""Small ROS 2 command line client for the MAVROS ArduCopter services."""

import argparse
import sys

import rclpy
from rclpy.qos import qos_profile_sensor_data
from mavros_msgs.msg import State, StatusText
from mavros_msgs.srv import CommandBool, CommandTOL, SetMode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('status', 'arm', 'disarm', 'mode', 'takeoff', 'land', 'rtl'))
    parser.add_argument('value', nargs='?', help='mode name, or takeoff altitude in metres')
    parser.add_argument('--namespace', default='/mavros', help='MAVROS namespace')
    parser.add_argument('--timeout', type=float, default=15.0, help='connection/service timeout in seconds')
    args = parser.parse_args()
    if args.command in ('mode', 'takeoff') and args.value is None:
        parser.error(f'{args.command} requires a value')
    if args.command not in ('mode', 'takeoff') and args.value is not None:
        parser.error(f'{args.command} takes no value')
    if args.timeout <= 0:
        parser.error('--timeout must be positive')

    altitude = None
    if args.command == 'takeoff':
        try:
            altitude = float(args.value)
        except ValueError:
            parser.error('takeoff altitude must be a number')
        if not 0 < altitude <= 100:
            parser.error('takeoff altitude must be greater than 0 and at most 100 metres')

    rclpy.init()
    node = rclpy.create_node('emsd_ardupilot_command')
    namespace = '/' + args.namespace.strip('/')
    state = None

    def on_state(message):
        nonlocal state
        state = message

    def on_status_text(message):
        print(f'ArduPilot: {message.text}', file=sys.stderr, flush=True)

    node.create_subscription(State, f'{namespace}/state', on_state, 10)
    node.create_subscription(
        StatusText, f'{namespace}/statustext/recv', on_status_text,
        qos_profile_sensor_data)
    try:
        from time import monotonic
        deadline = monotonic() + args.timeout
        while rclpy.ok() and (state is None or not state.connected) and monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=min(0.2, max(0, deadline - monotonic())))
        if state is None or not state.connected:
            raise RuntimeError(f'no connected ArduPilot heartbeat on {namespace}/state')

        if args.command == 'status':
            print(f'connected={state.connected} armed={state.armed} mode={state.mode}')
            return 0

        if args.command in ('mode', 'rtl'):
            service, srv_type = f'{namespace}/set_mode', SetMode
            request = srv_type.Request()
            request.custom_mode = args.value.upper() if args.command == 'mode' else 'RTL'
            result_field = 'mode_sent'
        elif args.command in ('arm', 'disarm'):
            service, srv_type = f'{namespace}/cmd/arming', CommandBool
            request = srv_type.Request()
            request.value = args.command == 'arm'
            result_field = 'success'
        else:
            service = f'{namespace}/cmd/{args.command}'
            srv_type = CommandTOL
            request = srv_type.Request()
            if altitude is not None:
                request.altitude = altitude
            result_field = 'success'

        client = node.create_client(srv_type, service)
        if not client.wait_for_service(timeout_sec=args.timeout):
            raise RuntimeError(f'service unavailable: {service}')
        future = client.call_async(request)
        rclpy.spin_until_future_complete(node, future, timeout_sec=args.timeout)
        if not future.done() or future.result() is None:
            raise RuntimeError(f'no response from {service}')
        response = future.result()
        if not getattr(response, result_field):
            # STATUSTEXT explaining rejection can arrive after the service ACK.
            deadline = monotonic() + min(2.0, args.timeout)
            while rclpy.ok() and monotonic() < deadline:
                rclpy.spin_once(node, timeout_sec=min(0.2, max(0, deadline - monotonic())))
            raise RuntimeError(f'{service} rejected command: {response}')
        if args.command in ('mode', 'rtl', 'arm', 'disarm'):
            def confirmed():
                if not state.connected:
                    return False
                if args.command in ('mode', 'rtl'):
                    return state.mode.upper() == request.custom_mode
                return state.armed == request.value

            deadline = monotonic() + args.timeout
            while rclpy.ok() and not confirmed() and monotonic() < deadline:
                rclpy.spin_once(node, timeout_sec=min(0.2, max(0, deadline - monotonic())))
            if not confirmed():
                raise RuntimeError(
                    f'{args.command} sent but not confirmed by heartbeat: '
                    f'connected={state.connected} armed={state.armed} mode={state.mode}')
            print(f'{args.command} confirmed: armed={state.armed} mode={state.mode}')
            return 0
        print(f'{args.command} accepted: {response}')
        return 0
    except RuntimeError as error:
        print(f'Error: {error}', file=sys.stderr)
        return 1
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    sys.exit(main())
