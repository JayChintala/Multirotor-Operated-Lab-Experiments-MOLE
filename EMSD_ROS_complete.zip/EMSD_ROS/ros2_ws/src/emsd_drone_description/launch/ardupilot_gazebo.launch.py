"""EMSD Gazebo Fortress plant + ArduCopter JSON SITL + MAVROS."""
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, ExecuteProcess, IncludeLaunchDescription, OpaqueFunction, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.substitutions import LaunchConfiguration
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource


def generate_launch_description():
    share = Path(get_package_share_directory('emsd_drone_description'))

    def start(context):
        value = lambda name: LaunchConfiguration(name).perform(context)
        root = Path(value('ardupilot_dir')).expanduser().resolve()
        binary = root / 'build/sitl/bin/arducopter'
        defaults = root / 'Tools/autotest/default_params/copter.parm'
        params = Path(value('params')).expanduser().resolve()
        for path in (binary, defaults, params):
            if not path.is_file():
                raise FileNotFoundError(f'Missing {path}; run tools/setup_ardupilot.sh first')
        state = Path(value('state_dir')).expanduser().resolve()
        state.mkdir(parents=True, exist_ok=True)
        cmd = [str(binary), '--model', 'JSON:127.0.0.1', '--rate', '400',
               '--speedup', '1', '--defaults', f'{defaults},{params}',
               '--home', '-35.363261,149.165230,584,90']
        if value('wipe').lower() == 'true':
            cmd.append('--wipe')
        sitl = ExecuteProcess(cmd=cmd, cwd=str(state), output='screen')
        gz_cmd = ['/usr/bin/python3', '-s', str(share / 'control/ardupilot_sim.py'),
                  '--config', value('config'), '--duration', value('duration')]
        if value('headless').lower() == 'true':
            gz_cmd.append('--headless')
        gazebo = ExecuteProcess(cmd=gz_cmd, output='screen',
                                additional_env={'PYTHONNOUSERSITE': '1'})
        mavros = IncludeLaunchDescription(
            XMLLaunchDescriptionSource(str(Path(get_package_share_directory('mavros')) / 'launch/apm.launch')),
            launch_arguments={'fcu_url': 'tcp://127.0.0.1:5760',
                              'gcs_url': 'udp://@127.0.0.1:14550'}.items())
        # Failure or completion of either half terminates the coupled simulation.
        handlers = [RegisterEventHandler(OnProcessExit(target_action=p,
                    on_exit=[EmitEvent(event=Shutdown(reason='Coupled simulation process exited'))]))
                    for p in (sitl, gazebo)]
        return handlers + [sitl, gazebo, mavros]

    return LaunchDescription([
        DeclareLaunchArgument('ardupilot_dir', default_value=str(Path.home() / 'ardupilot')),
        DeclareLaunchArgument('config', default_value=str(share / 'control/config/drone.json')),
        DeclareLaunchArgument('params', default_value=str(share / 'config/ardupilot/emsd.parm')),
        DeclareLaunchArgument('state_dir', default_value=str(Path.cwd() / 'simulation/runs/ardupilot_state')),
        DeclareLaunchArgument('headless', default_value='false'),
        DeclareLaunchArgument('duration', default_value='0'),
        DeclareLaunchArgument('wipe', default_value='false'),
        OpaqueFunction(function=start),
    ])
