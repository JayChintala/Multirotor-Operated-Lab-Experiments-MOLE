"""Start ArduCopter's native SITL and expose its MAVLink interface through MAVROS."""

from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource


def generate_launch_description():
    def start(context):
        root = Path(LaunchConfiguration('ardupilot_dir').perform(context)).expanduser().resolve()
        sim_vehicle = root / 'Tools/autotest/sim_vehicle.py'
        if not sim_vehicle.is_file():
            raise FileNotFoundError(f'ArduPilot SITL launcher missing: {sim_vehicle}')

        port = int(LaunchConfiguration('mavlink_port').perform(context))
        if not 1 <= port <= 65535:
            raise ValueError('mavlink_port must be between 1 and 65535')

        command = [str(sim_vehicle), '-v', 'ArduCopter', '-f', 'quad',
                   f'--out=127.0.0.1:{port}']
        if LaunchConfiguration('wipe').perform(context).lower() == 'true':
            command.append('-w')

        mavros_share = Path(get_package_share_directory('mavros'))
        mavros = IncludeLaunchDescription(
            XMLLaunchDescriptionSource(str(mavros_share / 'launch/apm.launch')),
            launch_arguments={'fcu_url': f'udp://0.0.0.0:{port}@'}.items(),
        )
        return [ExecuteProcess(cmd=command, cwd=str(root), output='screen'), mavros]

    return LaunchDescription([
        DeclareLaunchArgument('ardupilot_dir', default_value=str(Path.home() / 'ardupilot')),
        DeclareLaunchArgument('mavlink_port', default_value='14560'),
        DeclareLaunchArgument('wipe', default_value='false'),
        OpaqueFunction(function=start),
    ])
