# ArduPilot control of the EMSD quadcopter in Gazebo

This integration sends ArduCopter's motor outputs to the **existing EMSD
Gazebo Fortress plant**. Your mesh, CAD-derived inertia, 0.7 kg mass, measured
motor thrust/torque curves, motor lag, drag, contact and pond buoyancy remain in
the physical simulation. ArduPilot runs its own estimator, position, attitude,
rate control and motor mixer. Edit flight gains in ArduPilot parameters.
`control/config/drone.json` PID gains belong to the older Python controller and
do not affect this flight path.

```mermaid
flowchart LR
  GCS[Ground station / parameter tuning] <--> AP[ArduCopter SITL]
  ROS[ROS 2 custom controller] <--> MAV[MAVROS]
  MAV <--> AP
  AP -->|PWM over JSON backend UDP| MOTOR[Measured motors and lag]
  MOTOR -->|Force and torque| GZ[EMSD Gazebo DART dynamics]
  GZ -->|Position, velocity, attitude, IMU| AP
```

## Install on Ubuntu 22.04 / ROS 2 Humble

From the EMSD root, run:

```bash
bash tools/setup_ardupilot.sh "$HOME/ardupilot"
```

This installs MAVROS and GeographicLib data, clones ArduPilot if needed,
installs its prerequisites, builds ArduCopter SITL, and builds the EMSD ROS
package. It needs internet and sudo on your host. The original Gazebo/ROS
prerequisites in `SetupRos.md` are also required. An existing ArduPilot checkout
is used as-is; a new checkout uses the upstream default branch. Its exact Git
revision is recorded in `simulation/ardupilot-version.txt`. For reproducible
gain comparisons, keep the same ArduPilot revision and save your parameters.

## Launch the coupled simulation

```bash
source /opt/ros/humble/setup.bash
source ros2_ws/install/setup.bash
ros2 launch emsd_drone_description ardupilot_gazebo.launch.py \
  ardupilot_dir:="$HOME/ardupilot"
```

This launches the compiled `arducopter` binary with the JSON backend, Gazebo,
and MAVROS. No separate `sim_vehicle.py`, MAVProxy or second Gazebo is needed.
The simulation uses `/usr/bin/python3` with user site packages disabled so
Ubuntu's NumPy/SciPy binaries stay compatible. Gazebo inherits that setting.
The supplied URDF remains useful for RViz; the generated dynamic SDF adds the
inertial and physical data required for flight. Gazebo is the only vehicle
dynamics solver in this launch.

`headless:=true duration:=120` uses the same native force adapter and Gazebo
DART engine without GUI/transport and ends after 120 simulation seconds.
The default headless duration is 30 seconds when duration is zero; set an
explicit long duration for tuning. GUI runs continue until stopped by default.
Simulation runs at 400 physics steps/s with one new ArduPilot actuator frame
per step. A missing actuator stream stops physics after 60 seconds.

Both sides must restart together after a simulation reset or firmware restart.
Ctrl+C stops the launch. Only one instance can use the default ports at a time.

| Connection | Purpose |
| --- | --- |
| UDP 127.0.0.1:9002 | Gazebo JSON physics backend |
| TCP 127.0.0.1:5760 | SITL serial0, consumed by MAVROS |
| UDP 127.0.0.1:14550 | MAVROS forwarding for one ground station or flight check |
| `/mavros/*` | ROS telemetry, setpoints and commands |

Connect QGroundControl/Mission Planner to UDP 14550 for the parameter editor,
flight display and log tools. Alternatively, with MAVProxy installed:

```bash
mavproxy.py --master=udpin:127.0.0.1:14550
```

Use one consumer of UDP 14550 at a time. MAVROS owns the SITL TCP link.

## Fly and tune ArduPilot

Wait for EKF/GPS readiness and successful pre-arm checks, then in a second
terminal with both ROS setup files sourced:

```bash
ros2 run emsd_drone_description ardupilot_command.py status
ros2 run emsd_drone_description ardupilot_command.py mode GUIDED
ros2 run emsd_drone_description ardupilot_command.py arm
ros2 run emsd_drone_description ardupilot_command.py takeoff 2
ros2 topic echo /mavros/local_position/pose
# When finished:
ros2 run emsd_drone_description ardupilot_command.py land
```

For a bounded host acceptance test, close the ground station and run:

```bash
python3 tools/check_ardupilot_flight.py
```

It waits for the estimator, requests a 2 m GUIDED takeoff, confirms at least
1.8 m altitude, requests LAND, and waits for disarm. It sends LAND on failure;
inspect pre-arm messages if it cannot arm. It requires `pymavlink`, normally
installed by ArduPilot's prerequisite script. This check has **not been run in
the restricted development environment**.

In MAVProxy, for example:

```text
param show ATC_RAT_RLL_P
param set ATC_RAT_RLL_P 0.12
param show ATC_RAT_PIT_*
param show ATC_RAT_YAW_*
param save emsd_tuned.parm
```

These operate on the running flight controller. Use ArduPilot's tuning process
for `ATC_RAT_RLL_*`, `ATC_RAT_PIT_*`, `ATC_RAT_YAW_*`, attitude and vertical /
position control parameters. Change one group at a time and compare DataFlash
desired versus measured rates, oscillation, motor saturation and tracking.
AutoTune needs the normal ArduPilot mode/RC setup and a stable initial hover;
it is not automatically started by this integration.

`state_dir` defaults to `simulation/runs/ardupilot_state` relative to the launch
working directory. It holds EEPROM and ArduPilot DataFlash logs. This preserves
your live parameter changes between runs. `params:=/absolute/file.parm`
selects a defaults overlay after upstream `copter.parm`; saved EEPROM values
take precedence. `wipe:=true` resets EEPROM to the chosen defaults and discards
the saved tune. Export parameters before resetting. Gazebo's effective vehicle
configuration, generated world, and motor/pose telemetry CSV are written into
timestamped directories under `simulation/runs/`.

## Develop your controller

There are three useful levels of replacement:

1. **ROS outer controller:** edit
   `ros2_ws/src/emsd_drone_description/scripts/external_controller.py`.
   It computes bounded ENU velocity setpoints from position error at 20 Hz.
   After GUIDED takeoff, run:

   ```bash
   ros2 run emsd_drone_description external_controller.py --target 1 0 2
   ```

   Replace `velocity_controller()` with PID, MPC, or another method. ArduPilot
   keeps its estimator and inner loops. Stale feedback produces zero velocity.
   Stop the node and issue LAND when done. This example never arms or takes off
   automatically. Rebuild after edits when using a non-symlink install.

2. **External attitude/rate controller:** publish
   `mavros_msgs/msg/AttitudeTarget` to `/mavros/setpoint_raw/attitude` in the
   appropriate ArduPilot GUIDED mode, with the correct type mask and normalized
   thrust convention for `GUID_OPTIONS`. Check the ArduPilot version's supported
   fields. ROS MAVROS setpoints use ENU/FLU conventions; MAVROS does MAVLink
   frame conversion. The JSON backend conversion is separate.

3. **Full low-level controller:** for a controller running inside ArduPilot,
   modify its controller source and rebuild `./waf copter` in the checkout;
   this launch runs that binary. ArduPilot's Custom Controller facility can
   also be used when enabled in your firmware build. For a controller directly
   replacing the autopilot motor outputs, `control/final_control.py` already
   exposes `your_controller(state, reference, vehicle)` against the same Gazebo
   plant. Run it as documented in `SetupRos.md`. Direct motor replacement
   bypasses the ArduPilot estimator/control stack.

## Model conventions and limits

Gazebo world is ENU and body is FLU. JSON feedback is NED and FRD, with quaternion
order `[w,x,y,z]`. Specific force is calculated from successive Gazebo world
velocities with gravity removed, then rotated into FRD; at rest it is
`[0,0,-9.80665]`. SITL generates simulated GPS, barometer and compass from the
physical state and runs its EKF; no ground-truth ROS pose is used by its PID.
The bridge itself does not model IMU noise or sensor latency.

| EMSD motor | Location (body FLU) | AP output | FLU yaw reaction sign |
| --- | --- | --- | --- |
| 1 | front left (+X,+Y) | Motor 3 / SERVO3 | + |
| 2 | rear left (-X,+Y) | Motor 2 / SERVO2 | - |
| 3 | rear right (-X,-Y) | Motor 4 / SERVO4 | + |
| 4 | front right (+X,-Y) | Motor 1 / SERVO1 | - |

The supplied defaults require quad X and standard motor output functions. Keep
the above mapping when editing frame parameters. PWM 1000 is off, PWM 1100 is
the first measured spinning sample, and PWM 2000 is the last sample. Linear
interpolation below the first spinning sample is an assumption. The bench's
ESC signal values were not calibrated to flight-controller microseconds; this
mapping needs verification against your ESC/motor combination.

The model is useful for controller development, but a tune is only as accurate
as the plant. Motor mount/axis assumptions, mass distribution, motor lag, drag,
PWM scaling and thrust expo still need measurement. Battery sag, prop wash,
ground effect and detailed vibration are absent. The current PID numbers from
the older Python controller cannot be copied into ArduPilot: their units,
filters, mixer and control laws differ. Tune ArduPilot's own gains and validate
the model before transferring them to hardware.

## Verification and references

Local checks: `python3 -m unittest discover -s control -v`, source/install
build, generated SDF and launch argument loading. Tests cover NED/FRD
conversion, gravity/specific force, motor moment signs, true motor-off,
packet validation, duplicate replies and firmware restart rejection. Live
UDP/SITL/GUI flight validation requires the host because the development
environment disallows sockets, downloads and system installations.

- [ArduPilot JSON backend protocol](https://github.com/ArduPilot/ardupilot/blob/master/libraries/SITL/examples/JSON/readme.md)
- [ArduPilot quad motor matrix](https://github.com/ArduPilot/ardupilot/blob/master/libraries/AP_Motors/AP_MotorsMatrix.cpp)
- [ArduPilot manual tuning](https://ardupilot.org/copter/docs/tuning-process-instructions.html)
- [Guided movement commands](https://ardupilot.org/dev/docs/copter-commands-in-guided-mode.html)
- [Custom Controller](https://ardupilot.org/dev/docs/copter-adding-custom-controller.html)
- [MAVROS ROS 2](https://github.com/mavlink/mavros/tree/ros2)
