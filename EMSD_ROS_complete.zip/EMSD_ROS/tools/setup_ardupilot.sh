#!/usr/bin/env bash
# Run on the Ubuntu 22.04 host. Does not reset an existing ArduPilot checkout.
set -euo pipefail
emsd_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
ardupilot_dir=${1:-"$HOME/ardupilot"}
sudo apt-get update
sudo apt-get install -y git ros-humble-mavros ros-humble-mavros-msgs python3-colcon-common-extensions python3-numpy python3-scipy
sudo /opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh
if [[ ! -d "$ardupilot_dir" ]]; then
  git clone --recurse-submodules https://github.com/ArduPilot/ardupilot.git "$ardupilot_dir"
fi
cd -- "$ardupilot_dir"
git submodule update --init --recursive
./Tools/environment_install/install-prereqs-ubuntu.sh -y
./waf configure --board sitl
./waf copter -j2
git rev-parse HEAD > "$emsd_root/simulation/ardupilot-version.txt"
# ROS environment setup scripts may reference unset variables.
set +u
source /opt/ros/humble/setup.bash
cd -- "$emsd_root/ros2_ws"
colcon build --symlink-install --packages-select emsd_drone_description
