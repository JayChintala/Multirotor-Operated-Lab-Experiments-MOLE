#!/usr/bin/env python3
"""Plot a snapshot of Gazebo/ArduPilot telemetry; target is user-supplied."""
import argparse
import io
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR', '/tmp/emsd_matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('csv', nargs='?', type=Path)
    parser.add_argument('--target', type=float, default=2.)
    args = parser.parse_args()
    candidates = list((ROOT/'simulation/runs').glob('*/telemetry.csv'))
    candidates = [p for p in candidates if 'pwm_motor_1' in p.open().readline()]
    path = args.csv or max(candidates, key=lambda p: p.stat().st_mtime)
    # Drop any unfinished row when reading a still-running simulation.
    snapshot = path.read_bytes().rsplit(b'\n', 1)[0].decode()
    data = np.atleast_1d(np.genfromtxt(io.StringIO(snapshot), delimiter=',', names=True))
    data = data[np.isfinite(data['time_s']) & np.isfinite(data['z_m'])]
    if len(data) < 2:
        raise SystemExit('Need at least two complete telemetry rows')
    t = data['time_s']
    # Resting ground height, excluding the initial spawn/settling transient.
    ground = float(np.median(data['z_m'][(t >= t[0]+1) & (t <= t[0]+5)]))
    h = data['z_m']-ground
    airborne = np.flatnonzero((h > .10) & (t > t[0]+5))
    if not len(airborne):
        raise SystemExit('No takeoff detected above 0.10 m after initial settling')
    start = t[airborne[0]]
    mask = t >= start-3
    t = t[mask]-start
    d = data[mask]
    h = h[mask]
    post = t >= 0
    final = t >= max(0, t[-1]-5)
    metrics = {'source': str(path), 'ground_world_z_m': ground,
               'liftoff_detection_sim_time_s': float(start),
               'snapshot_end_sim_time_s': float(data['time_s'][-1]),
               'requested_reference_m': args.target,
               'peak_height_above_rest_m': float(h[post].max()),
               'last_5s_mean_height_m': float(h[final].mean()),
               'last_5s_std_height_m': float(h[final].std()),
               'note': 'Time zero is detected liftoff, not command time. Reference is supplied, not logged. Final window may not be settled.'}
    fig, axes = plt.subplots(4, 1, figsize=(11, 11), sharex=True, layout='constrained')
    axes[0].plot(t, h, label='Gazebo height above rest')
    axes[0].axhline(args.target, color='black', ls='--', label='Requested reference (not logged)')
    axes[0].set_ylabel('Height [m]'); axes[0].legend()
    for name in ['x_m', 'y_m']:
        axes[1].plot(t, d[name]-d[name][0], label=name[0])
    axes[1].set_ylabel('Displacement [m]'); axes[1].legend()
    for name in ['roll', 'pitch', 'yaw']:
        axes[2].plot(t, np.rad2deg(np.unwrap(d[name+'_rad'])), label=name)
    axes[2].set_ylabel('Angle [deg]'); axes[2].legend()
    for i in range(1, 5):
        axes[3].plot(t, d[f'pwm_motor_{i}'], label=f'Motor {i}', alpha=.8)
    axes[3].set_ylabel('PWM [µs]'); axes[3].legend(ncol=4)
    axes[3].set_xlabel('Simulation time since detected liftoff [s]')
    for ax in axes:
        ax.grid(alpha=.25)
    fig.suptitle(f'ArduPilot takeoff response — {path.parent.name}\nGround truth; command timestamp and estimator target are not recorded')
    out = path.parent/'response'
    for suffix in ['png', 'pdf']:
        fig.savefig(out.with_suffix('.'+suffix), dpi=160)
    out.with_suffix('.json').write_text(json.dumps(metrics, indent=2)+'\n')
    print(json.dumps(metrics, indent=2))
    print(out.with_suffix('.png'))

if __name__ == '__main__':
    main()
