#!/usr/bin/env python3
"""Host acceptance check: GUIDED takeoff to 2 m, then LAND and disarm.

Run only against the launched SITL. Requires pymavlink from ArduPilot setup.
Uses MAVROS's GCS output, so close MAVProxy/QGroundControl on port 14550 first.
"""
import argparse
import time

from pymavlink import mavutil


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--connection', default='udpin:127.0.0.1:14550')
    args = parser.parse_args()
    link = mavutil.mavlink_connection(args.connection, source_system=255)
    last_heartbeat = 0.

    def wait_for(predicate, description, timeout=90):
        nonlocal last_heartbeat
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if link.target_system and time.monotonic()-last_heartbeat >= 1:
                link.mav.heartbeat_send(mavutil.mavlink.MAV_TYPE_GCS, mavutil.mavlink.MAV_AUTOPILOT_INVALID, 0, 0, 0)
                last_heartbeat = time.monotonic()
            msg = link.recv_match(blocking=True, timeout=.5)
            if msg is None:
                continue
            if msg.get_type() == 'STATUSTEXT':
                print(msg.text, flush=True)
            if predicate(msg):
                print(description, flush=True)
                return
        raise RuntimeError(f'Timed out waiting for {description}; inspect pre-arm and EKF messages')

    try:
        wait_for(lambda m: m.get_type() == 'HEARTBEAT' and m.autopilot == mavutil.mavlink.MAV_AUTOPILOT_ARDUPILOTMEGA,
                 'ArduPilot heartbeat received')
        link.mav.request_data_stream_send(link.target_system, link.target_component,
                                         mavutil.mavlink.MAV_DATA_STREAM_ALL, 10, 1)
        wait_for(lambda m: m.get_type() == 'EKF_STATUS_REPORT' and (m.flags & 0x33) == 0x33,
                 'EKF attitude, horizontal velocity, absolute horizontal position and vertical position ready')
        link.set_mode('GUIDED')
        wait_for(lambda m: m.get_type() == 'HEARTBEAT' and m.custom_mode == 4, 'GUIDED confirmed', 15)
        link.arducopter_arm()
        wait_for(lambda m: m.get_type() == 'HEARTBEAT' and bool(m.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED),
                 'Armed', 20)
        link.mav.command_long_send(link.target_system, link.target_component,
                                   mavutil.mavlink.MAV_CMD_NAV_TAKEOFF, 0, 0, 0, 0, 0, 0, 0, 2.)
        wait_for(lambda m: m.get_type() == 'GLOBAL_POSITION_INT' and m.relative_alt >= 1800,
                 'Reached at least 1.8 m relative altitude', 45)
        link.set_mode('LAND')
        wait_for(lambda m: m.get_type() == 'HEARTBEAT' and not (m.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED),
                 'Landed and disarmed', 60)
        print('PASS: SITL takeoff and landing completed')
    except (RuntimeError, KeyboardInterrupt):
        if link.target_system:
            link.set_mode('LAND')
        raise
    finally:
        link.close()


if __name__ == '__main__':
    main()
