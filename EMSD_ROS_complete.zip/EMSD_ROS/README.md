# EMSD ROS source bundle

Contains all ros2_ws/src files (launch files, scripts, URDF, meshes, RViz,
worlds, parameters and package build metadata), plus the control and simulation
sources required by the package CMakeLists.txt. Preserve this directory layout.
Build/install/log directories and saved SITL state are excluded.

Read simulation/ARDUPILOT.md for installation and launch instructions, and
control/ARDUPILOT_TUNING.md for tuning and the lessons from flight testing.

Build from this bundle root after installing dependencies:

    source /opt/ros/humble/setup.bash
    cd ros2_ws
    colcon build --symlink-install --packages-select emsd_drone_description
    source install/setup.bash

SCHED_LOOP_RATE must be set to 200 in existing saved SITL state and the full
simulation restarted for the current 400 Hz JSON gyro stream. See the tuning
notes. The command helper includes best-effort status-text reception and
heartbeat confirmation for mode and arming changes.

This archive can be extracted into a Git repository. It does not include the
external ROS, Gazebo or ArduPilot installations.
