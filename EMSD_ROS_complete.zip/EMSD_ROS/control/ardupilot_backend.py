"""ArduPilot JSON lockstep backend for EMSD's Gazebo force plugin.

Gazebo world ENU and body FLU are converted to ArduPilot NED and FRD.
No flight control gains or allocation from physics_control are used here.
"""
import csv
import json
import socket
import struct
import time

import numpy as np
from scipy.spatial.transform import Rotation

from drone_control import MotorTable
from final_control import motor_wrench
from physics_control import GRAVITY, load_config
from water_physics import buoyancy_wrench, component_samples

ENU_TO_NED = np.array([[0., 1., 0.], [1., 0., 0.], [0., 0., -1.]])
FLU_TO_FRD = np.diag([1., -1., -1.])
# EMSD FL, RL, RR, FR receive ArduPilot motors 3, 2, 4, 1.
MOTOR_CHANNELS = np.array([2, 1, 3, 0])
SERVO_PACKET = struct.Struct('<HHI16H')


def decode_actuators(packet):
    if len(packet) != SERVO_PACKET.size:
        raise ValueError('Expected ArduPilot 16-channel servo packet (40 bytes)')
    magic, rate, frame, *pwm = SERVO_PACKET.unpack(packet)
    if magic != 18458 or rate == 0:
        raise ValueError('Invalid ArduPilot JSON servo packet')
    return frame, np.asarray(pwm)


def sensor_state(t, position, quaternion, velocity, rates, acceleration):
    rotation = Rotation.from_quat(quaternion).as_matrix()
    # Accelerometers measure specific force, including the ground reaction.
    specific_force = rotation.T @ (np.asarray(acceleration) + [0., 0., GRAVITY])
    ap_quat = Rotation.from_matrix(ENU_TO_NED @ rotation @ FLU_TO_FRD).as_quat()
    return {'timestamp': float(t) + 1e-6,
            'imu': {'gyro': (FLU_TO_FRD @ rates).tolist(),
                    'accel_body': (FLU_TO_FRD @ specific_force).tolist()},
            'position': (ENU_TO_NED @ position).tolist(),
            'velocity': (ENU_TO_NED @ velocity).tolist(),
            'quaternion': ap_quat[[3, 0, 1, 2]].tolist()}


class JSONLink:
    """One physics step per actuator frame; duplicate packets resend state."""
    def __init__(self, port=9002, timeout=60.):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(('127.0.0.1', port))
        self.socket.settimeout(1.)
        self.timeout = timeout
        self.peer = None
        self.frame = None

    def exchange(self, state):
        message = ('\n' + json.dumps(state, allow_nan=False) + '\n').encode()
        if self.peer is not None:
            self.socket.sendto(message, self.peer)
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            try:
                packet, peer = self.socket.recvfrom(2048)
            except socket.timeout:
                continue
            if self.peer is not None and peer != self.peer:
                continue
            try:
                frame, pwm = decode_actuators(packet)
            except ValueError:
                continue
            if self.frame is not None and frame < self.frame:
                raise RuntimeError('SITL restarted: restart the complete Gazebo/SITL launch')
            self.peer = peer
            if self.frame is None or frame == self.frame:
                self.socket.sendto(message, peer)
                if self.frame is None:
                    self.frame = frame
                continue
            self.frame = frame
            return pwm
        raise RuntimeError('ArduPilot JSON link timed out; physics stopped')


class PhysicsController:
    def __init__(self, filename):
        self.config = c = load_config(filename)
        self.link = JSONLink(timeout=c.get('sitl_timeout_s', 60.))
        self.tables = [MotorTable(p) for p in c['motor_tables']]
        self.positions = np.asarray(c['motor_positions_m']) - c['com_m']
        self.signs = np.asarray(c['yaw_signs'])
        if not np.array_equal(self.signs, [1, -1, 1, -1]):
            raise ValueError('Quad X requires EMSD yaw signs [+1,-1,+1,-1]')
        self.actual = np.zeros(4)
        self.last_velocity = None
        self.last_time = None
        self.water = c['water']
        if self.water:
            self.water_points, self.water_volumes = component_samples(c)
        self.log = open(c['telemetry_csv'], 'w', newline='', buffering=1) if c.get('telemetry_csv') else None
        if self.log:
            self.writer = csv.writer(self.log)
            self.writer.writerow(['time_s', 'x_m', 'y_m', 'z_m', 'roll_rad', 'pitch_rad', 'yaw_rad'] +
                                  [f'pwm_motor_{i}' for i in range(1, 5)] +
                                  [f'thrust_motor_{i}_n' for i in range(1, 5)])

    def update(self, t, position, quaternion, velocity, rates, dt):
        if self.last_time is not None and t <= self.last_time:
            raise ValueError('Restart the complete launch after resetting simulation time')
        position, velocity, rates = map(np.asarray, (position, velocity, rates))
        acceleration = np.zeros(3) if self.last_velocity is None else (velocity-self.last_velocity)/(t-self.last_time)
        self.last_velocity, self.last_time = velocity.copy(), t
        pwm = self.link.exchange(sensor_state(t, position, quaternion, velocity, rates, acceleration))
        target = np.clip((pwm[MOTOR_CHANNELS]-1000.) / 1000., 0., 1.)
        self.actual += -np.expm1(-dt/np.asarray(self.config['motor_time_constant_s'])) * (target-self.actual)
        # Off is truly zero; PWM 1100 is the first measured spinning sample.
        # The bench's command scale is not a calibrated physical PWM scale.
        thrust, reaction = np.zeros(4), np.zeros(4)
        for i, table in enumerate(self.tables):
            x = np.r_[0., .1 + .9*table.data[:, 0]]
            thrust[i] = np.interp(self.actual[i], x, np.r_[0., table.data[:, 1]])
            reaction[i] = np.interp(self.actual[i], x, np.r_[0., table.data[:, 2]])
        force, moments = motor_wrench(self.positions, thrust, reaction, self.signs)
        torque = moments.sum(axis=0)
        rotation = Rotation.from_quat(quaternion)
        force -= self.config['linear_drag_n_per_m_s'] * rotation.inv().apply(velocity)
        torque -= self.config['angular_drag_nm_per_rad_s'] * rates
        if self.water:
            wf, wt = buoyancy_wrench(position, rotation.as_matrix(), self.water_points, self.water_volumes, self.water)
            force += wf
            torque += wt
        if self.log:
            self.writer.writerow([t, *position, *rotation.as_euler('xyz'), *pwm[MOTOR_CHANNELS], *thrust])
        return [*force, *torque]
