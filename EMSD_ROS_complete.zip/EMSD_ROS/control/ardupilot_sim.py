"""Run EMSD Gazebo physics under ArduPilot control (start SITL separately)."""
import argparse
import json
from pathlib import Path
import tempfile

from physics_control import DEFAULT_CONFIG, load_config
from physics_sim import main as run_physics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=DEFAULT_CONFIG)
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--duration', type=float, default=0)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    config = load_config(args.config)
    config['physics_step_s'] = .0025  # Matched to SITL --rate 400.
    args.controller_module = 'ardupilot_backend'
    args.mode = 'ardupilot'
    args.rates = [0., 0., 0.]
    args.roll_deg = args.pitch_deg = args.yaw_deg = 0.
    args.motor_commands = [0.] * 4
    with tempfile.TemporaryDirectory(prefix='emsd_ardupilot_') as directory:
        args.config = Path(directory) / 'drone.json'
        args.config.write_text(json.dumps(config))
        run_physics(args)


if __name__ == '__main__':
    main()
