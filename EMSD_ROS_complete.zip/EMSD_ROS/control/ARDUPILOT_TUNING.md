# EMSD ArduPilot simulation tuning

Replot the latest ArduPilot CSV snapshot:

```bash
cd ~/Desktop/EMSD
python3 tools/plot_ardupilot_response.py
# Or select a run:
python3 tools/plot_ardupilot_response.py simulation/runs/20261108_180605_6460/telemetry.csv --target 2
```

PNG, PDF and JSON statistics are written alongside the CSV. The dashed line is the supplied requested height, not a logged controller target. Height is world Z minus the median resting height at simulation seconds 1–5. Time zero is first detected height above 0.1 m after initial settling, not command time. The final five seconds may include landing; they are not automatically hover statistics. These conventions do not establish the autopilot's home altitude or estimator offset.

## What to tune, in order

1. **Validate the plant.** `control/config/drone.json` contains mass, inertia, centre of mass, motor positions, motor time constants, and drag. Current mass is 0.7 kg; motor lag is an assumed 0.04 s. Motor tables supply measured steady-state thrust and reaction torque. Confirm physical measurements before adjusting these values; gains should not compensate for an incorrect plant. The backend maps PWM to the measured table using a provisional mapping. `rate_kp`, `rate_ki`, etc. in the Python controller configuration do not tune ArduPilot: this backend receives its PWM outputs from SITL.
2. **Keep timing fixed.** The JSON plant runs at 400 Hz (2.5 ms). `SCHED_LOOP_RATE=200` satisfies the observed gyro check, which requires at least 1.8 sensor samples per loop. Set the parameter in the running FCU, restart the complete coupled launch, then verify. Saved SITL parameters override defaults. Do not disable arming checks to tune.
3. **Validate thrust setup.** Review `MOT_PWM_MIN/MAX`, `MOT_SPIN_ARM/MIN`, `MOT_THST_EXPO`, and `MOT_THST_HOVER`. Allow hover learning only during stable flight. Compare PWM and thrust against vehicle weight. A saturated motor or poor thrust mapping needs correction before increasing controller gains. The simulation has no fitted battery sag model.
4. **Tune angular rates first.** Use `ATC_RAT_RLL_P/I/D`, then `ATC_RAT_PIT_P/I/D`, then yaw. P corrects current rate error; I removes persistent error; D damps rapid changes but amplifies noise. Persistent roll oscillation in the present run makes this the first controller investigation. Compare demanded and actual rates in DataFlash logs before deciding whether P, D, filtering or actuator lag is responsible. Do not assume an altitude curve uniquely identifies a PID defect. Use small changes (for example 5–10% per experiment) as an experimental starting method, with one parameter changed each run; restore the previous value if oscillations or motor activity increase.
5. **Tune attitude and shaping.** Once rates track cleanly, review `ATC_ANG_RLL_P`, `ATC_ANG_PIT_P`, yaw angle gain, `ATC_INPUT_TC`, and angular acceleration limits. More angle P requests faster correction but can excite an insufficiently damped rate loop. Input shaping governs command aggressiveness; increasing gains is not the only way to change response speed.
6. **Tune vertical control from the inside out.** First acceleration/throttle, then vertical velocity, then vertical position; review hover thrust and estimator data first. Local source uses `PSC_D_ACC_P/I/D`, `PSC_D_VEL_P/I/D`, and `PSC_D_POS_P`. Older firmware uses `PSC_ACCZ_*`, `PSC_VELZ_*`, and `PSC_POSZ_P`. Some gains changed units/scaling: local acceleration P/I/D are 0.1 times their old counterparts. Inspect your actual firmware parameter metadata; never copy numerical gains across versions. Reduce excessive acceleration/jerk demands if the trajectory itself is too aggressive.
7. **Tune horizontal control last.** Local source uses `PSC_NE_POS_*` and `PSC_NE_VEL_*`; older firmware uses `PSC_POSXY_*` and `PSC_VELXY_*`. Test a small position step after roll/pitch tracking is stable. Review navigation speed, acceleration and jerk limits separately from feedback gains.
8. **Treat estimation and filtering separately.** Compare ground truth, estimated altitude and desired altitude. A ground-truth height offset can result from home/estimator differences; adding integral gain is not automatically the solution. Inspect gyro spectra before adjusting notch or low-pass filters. The simplified rigid-body plant cannot validate real structural vibration filtering. AutoTune requires a basically flyable vehicle and initial manual tuning.

## Repeatable experiments

Save the active FCU parameters through your ground station before changes. Record firmware revision, effective Gazebo config, and one changed parameter with each run. Changing `emsd.parm` changes defaults; it does not reliably update existing saved SITL state. Preserve a known-good parameter file and avoid wiping state unless you intend to reset all saved settings.

Use the same takeoff height, hover duration and landing sequence each run. Separate takeoff, hover and landing windows. Compare peak height, overshoot relative to the correct target frame, rise time measured from the logged command, settling time within a stated tolerance, hover error, roll/pitch RMS, motor saturation and output variation. Repeat promising settings. An apparently smooth altitude response with oscillating attitude is not a finished tune.

For detailed diagnosis use `simulation/runs/ardupilot_state/logs/*.BIN`. Inspect available message fields rather than assuming a fixed version: RATE desired/actual rates, ATT desired/actual attitude, CTUN desired/estimated/barometric altitude, RCOU motor output, PID terms, and estimator innovations where logged. Enable missing logging before the next experiment. The Gazebo CSV alone has no controller demand, PID components, or command timestamps and cannot provide true command-to-response delay or rate tracking error.

Set an existing floating-point parameter through MAVROS (replace NAME and VALUE):

```bash
ros2 service call /mavros/param/set mavros_msgs/srv/ParamSetV2 \
  "{param_id: 'NAME', value: {type: 3, double_value: VALUE}}"
```

Require `success: true`, read back the value with your ground station, and restart for parameters whose metadata requires it. Test simulation gains here; hardware needs its own measured plant, filters and validation.

Sources:
- https://ardupilot.org/copter/docs/tuning-process-instructions.html
- https://ardupilot.org/copter/docs/setting-up-for-tuning.html
- https://ardupilot.org/copter/docs/altholdmode.html
- Local firmware metadata: `~/ardupilot/libraries/AC_AttitudeControl/AC_PosControl.cpp`, `~/ardupilot/libraries/AP_Scheduler/AP_Scheduler.cpp`.
