"""Check the protocol, frame transforms and physical motor signs without SITL."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
from scipy.spatial.transform import Rotation

from ardupilot_backend import JSONLink, PhysicsController, SERVO_PACKET, decode_actuators, sensor_state
from physics_control import GRAVITY, load_config


class ArduPilotTests(unittest.TestCase):
    def test_sensor_frames_and_specific_force(self):
        state = sensor_state(1., np.array([1, 2, 3]), [0, 0, 0, 1],
                             np.array([4, 5, 6]), np.array([.1, .2, .3]), np.zeros(3))
        np.testing.assert_allclose(state['position'], [2, 1, -3])
        np.testing.assert_allclose(state['velocity'], [5, 4, -6])
        np.testing.assert_allclose(state['imu']['gyro'], [.1, -.2, -.3])
        np.testing.assert_allclose(state['imu']['accel_body'], [0, 0, -GRAVITY])
        q = np.array(state['quaternion'])[[1, 2, 3, 0]]
        np.testing.assert_allclose(Rotation.from_quat(q).as_euler('xyz'), [0, 0, np.pi/2], atol=1e-12)
        freefall = sensor_state(1, np.zeros(3), [0, 0, 0, 1], np.zeros(3), np.zeros(3), [0, 0, -GRAVITY])
        np.testing.assert_allclose(freefall['imu']['accel_body'], 0)

    def test_protocol_rejects_bad_packets(self):
        frame, pwm = decode_actuators(SERVO_PACKET.pack(18458, 400, 123, *([1500]*16)))
        self.assertEqual(frame, 123)
        self.assertEqual(pwm[0], 1500)
        for packet in (b'', SERVO_PACKET.pack(0, 400, 0, *([1000]*16))):
            with self.assertRaises(ValueError):
                decode_actuators(packet)

    def test_duplicate_resends_and_restart_stops(self):
        link = JSONLink.__new__(JSONLink)
        link.peer, link.frame, link.timeout = None, None, 1.
        from unittest.mock import Mock
        link.socket = Mock()
        peer = ('127.0.0.1', 1234)
        packet = lambda frame: (SERVO_PACKET.pack(18458, 400, frame, *([1000]*16)), peer)
        link.socket.recvfrom.side_effect = [packet(10), packet(10), packet(11)]
        link.exchange({'timestamp': 0.})
        self.assertEqual(link.frame, 11)
        self.assertEqual(link.socket.sendto.call_count, 2)
        link.socket.recvfrom.side_effect = [packet(0)]
        with self.assertRaises(RuntimeError):
            link.exchange({'timestamp': .1})

    def test_off_and_individual_ardupilot_motor_moments(self):
        with tempfile.TemporaryDirectory() as directory:
            c = load_config()
            c.update(water=None, linear_drag_n_per_m_s=0, angular_drag_nm_per_rad_s=0)
            path = Path(directory) / 'config.json'
            path.write_text(json.dumps(c))
            with patch('ardupilot_backend.JSONLink') as link:
                link.return_value.exchange.return_value = np.full(16, 1000)
                controller = PhysicsController(path)
                np.testing.assert_allclose(controller.update(0, [0, 0, .15], [0, 0, 0, 1], [0]*3, [0]*3, .0025), 0)
                # Expected FRD torque signs for AP motors FR, RL, FL, RR.
                for channel, signs in enumerate(([-1, 1, 1], [1, -1, 1], [1, 1, -1], [-1, -1, -1])):
                    pwm = np.full(16, 1000)
                    pwm[channel] = 1600
                    link.return_value.exchange.return_value = pwm
                    controller = PhysicsController(path)
                    wrench = controller.update(0, [0, 0, .15], [0, 0, 0, 1], [0]*3, [0]*3, .04)
                    np.testing.assert_array_equal(np.sign(np.array(wrench[3:])*[1, -1, -1]), signs)


if __name__ == '__main__':
    unittest.main()
